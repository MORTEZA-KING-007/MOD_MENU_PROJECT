package androtrainer;
import android.widget.Toast;
import android.content.Context;

public class Natives {
	protected static boolean loaded=false;
	private static Context getContext;
	public static void load()
	{ // load shared library
		if (!loaded)	{
			try	{
				System.loadLibrary("gg");
			} catch (Exception ex)	{
				android.util.Log.e("Cannot load shared library for your trainer", ex.toString());
				System.exit(0);
				}
			loaded = true;
		}
	}
}




